Yuntai 0.8.28 caption and pairing update. Read services/NATIVE_SUBTITLE_UPDATE.md. No keys are included. Run bash services/update_caption_service.sh from this extracted root in Cloud Shell.
