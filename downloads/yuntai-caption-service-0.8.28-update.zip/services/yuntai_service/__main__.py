"""Run behind an HTTPS reverse proxy with body/rate/connection limits.

python3 -m services.yuntai_service --db /var/lib/yuntai/service.sqlite
Default binds loopback only; never expose this plaintext development listener.
"""
import argparse
import json
import os
import socketserver
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from .core import Denied, GoogleIntegrity, Groq, Store


class Server(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True
    def __init__(self, address, handler, store):
        self.store = store
        self.workers = threading.BoundedSemaphore(8)
        super().__init__(address, handler)

    def process_request(self, request, address):
        if not self.workers.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except Exception:
            self.workers.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.workers.release()

    def handle_error(self, request, address):
        pass  # Never dump request data, tokens or audio into logs.


class Handler(BaseHTTPRequestHandler):
    server_version = 'Yuntai'
    sys_version = ''
    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, *_):
        pass

    def do_GET(self):
        healthy=self.path in ('/healthz','/v1/health')
        self.reply(200 if healthy else 404,
            {'status':'ok'} if healthy else {'error':'not_found'})
        self.close_connection=True

    def do_POST(self):
        try:
            limits = {'/v1/challenge':512,'/v1/session':16000,'/v1/feedback':16384,'/v1/captions':128044,'/v1/translate':4096}
            limit = limits.get(self.path)
            if limit is None:
                raise Denied(404)
            if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length',[])) != 1:
                raise Denied(400)
            length = int(self.headers.get('Content-Length','0'))
            if not 0<length<=limit:
                raise Denied(413)
            deadline=time.monotonic()+8
            chunks=[]
            remaining=length
            while remaining:
                budget=deadline-time.monotonic()
                if budget<=0:
                    raise Denied(408)
                self.connection.settimeout(budget)
                part=self.rfile.read1(min(8192,remaining))
                if not part:
                    raise Denied(400)
                chunks.append(part);remaining-=len(part)
            body=b''.join(chunks)
            store = self.server.store
            peer = store.peer_id(self.client_address[0])
            if self.path=='/v1/challenge':
                obj=json.loads(body)
                if set(obj)!={'public_key'}:
                    raise Denied(400)
                result=store.challenge(obj['public_key'],peer)
            elif self.path=='/v1/session':
                result=store.session(json.loads(body),peer)
            elif self.path=='/v1/feedback':
                result=store.feedback(self.headers,body)
            elif self.path=='/v1/translate':
                if self.headers.get('Content-Type')!='application/json':raise Denied(400)
                result=store.translate(self.headers,body)
            else:
                if self.headers.get('Content-Type')!='audio/wav':
                    raise Denied(400)
                result=store.caption(self.headers,body)
            self.reply(200,result)
        except Denied as failure:
            if self.path in ('/v1/captions','/v1/translate') and (failure.code>=500 or failure.code in (403,429)):
                reason=failure.reason if failure.reason in {'state_unavailable','provider_auth_error','provider_bad_request','provider_bad_response','provider_unavailable','unavailable','busy','quota_reached','provider_busy','device_not_approved','device_not_authorized'} else 'request_failed'
                print(json.dumps({'severity':'WARNING','event':'caption_request_failure','status':failure.code,'reason':reason}),flush=True)
            self.reply(failure.code,{'error':failure.reason},failure.retry)
        except (ValueError,TypeError,KeyError):
            self.reply(400,{'error':'invalid_request'})
        except Exception as error:
            if self.path in ('/v1/captions','/v1/translate'):
                print(json.dumps({'severity':'ERROR','event':'caption_request_failure','status':503,'reason':'internal_error','exception_type':type(error).__name__[:64]}),flush=True)
            self.reply(503,{'error':'unavailable'},60)
        finally:
            self.close_connection=True

    def reply(self, code, payload, retry=None):
        body=json.dumps(payload,ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        if retry:
            self.send_header('Retry-After',str(retry))
        self.end_headers()
        self.wfile.write(body)


def configuration(environment):
    cloud = bool(environment.get('K_SERVICE'))
    backend = environment.get('YUNTAI_STORE','firestore' if cloud else 'sqlite')
    if backend not in ('sqlite','firestore'):
        raise ValueError('Unknown state backend')
    if cloud and (backend!='firestore' or environment.get('GOOGLE_APPLICATION_CREDENTIALS') or environment.get('FIRESTORE_EMULATOR_HOST')):
        raise ValueError('Cloud Run requires durable Firestore and its assigned service identity')
    port = int(environment.get('PORT','8788'))
    if not 1<=port<=65535:
        raise ValueError('Invalid port')
    return backend, '0.0.0.0' if environment.get('PORT') else '127.0.0.1', port


def authentication(environment):
    mode=environment.get('YUNTAI_AUTH_MODE','play_integrity')
    if mode not in ('play_integrity','private_beta'):
        raise ValueError('Unknown authentication mode')
    return mode


def main():
    backend, host, port = configuration(os.environ)
    args=argparse.ArgumentParser()
    args.add_argument('--db')
    args.add_argument('--port',type=int,default=port)
    options=args.parse_args()
    if backend=='sqlite' and not options.db:
        args.error('--db is required for the local SQLite backend')
    auth_mode=authentication(os.environ)
    integrity=None if auth_mode=='private_beta' else GoogleIntegrity(os.environ.get('GOOGLE_APPLICATION_CREDENTIALS') or None,
        os.environ.get('YUNTAI_PACKAGE','com.yuntai.android.apps.livetv'),
        [value.strip() for value in os.environ['YUNTAI_CERTIFICATES'].split(',') if value.strip()])
    provider=Groq(os.environ['GROQ_API_KEY'],os.environ.get('YUNTAI_ASR_MODEL','whisper-large-v3'),
        os.environ.get('YUNTAI_TRANSLATION_MODEL','openai/gpt-oss-120b'))
    settings=dict(secret=os.environ['YUNTAI_SERVER_SECRET'].encode(), integrity=integrity, captions=provider,auth_mode=auth_mode,
        device_seconds=int(os.environ.get('YUNTAI_DEVICE_DAILY_BILLED_SECONDS','1800')),
        global_seconds=int(os.environ.get('YUNTAI_GLOBAL_DAILY_BILLED_SECONDS','7200')),
        global_rpm=int(os.environ.get('YUNTAI_GLOBAL_REQUESTS_PER_MINUTE','18')))
    if backend=='firestore':
        from google.cloud import firestore
        from .firestore_store import FirestoreStore
        project = os.environ.get('GOOGLE_CLOUD_PROJECT')
        if not project:
            raise ValueError('GOOGLE_CLOUD_PROJECT is required')
        store=FirestoreStore(firestore.Client(project=project, database=os.environ.get('YUNTAI_FIRESTORE_DATABASE','(default)')),**settings)
    else:
        os.umask(0o077)
        store=Store(options.db,**settings)
        os.chmod(options.db,0o600)
    Server((host,options.port),Handler,store).serve_forever()


if __name__=='__main__':
    main()
