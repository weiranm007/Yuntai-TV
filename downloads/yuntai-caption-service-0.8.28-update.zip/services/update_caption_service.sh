#!/usr/bin/env bash
set -euo pipefail
# Image-only update of the existing service; never recreate Firestore, IAM or secrets.
YUNTAI_UPDATE_PROJECT=yuntai-app
YUNTAI_UPDATE_REGION=us-central1
YUNTAI_UPDATE_SERVICE=yuntai-api
YUNTAI_UPDATE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[[ "$(gcloud projects describe "$YUNTAI_UPDATE_PROJECT" --format='value(projectNumber)')" == 605035871673 ]] || { echo 'Project mismatch; stopped.';exit 2; }
YUNTAI_UPDATE_AUTH="$(gcloud run services describe "$YUNTAI_UPDATE_SERVICE" --project="$YUNTAI_UPDATE_PROJECT" --region="$YUNTAI_UPDATE_REGION" --format=json | python3 -c 'import json,sys; s=json.load(sys.stdin); print(next((e.get("value","") for e in s["spec"]["template"]["spec"]["containers"][0].get("env",[]) if e.get("name")=="YUNTAI_AUTH_MODE"),"play_integrity"))')"
[[ "$YUNTAI_UPDATE_AUTH" == private_beta || "$YUNTAI_UPDATE_AUTH" == play_integrity ]] || { echo 'Unknown existing authorization mode; stopped.';exit 2; }
YUNTAI_UPDATE_IMAGE="$YUNTAI_UPDATE_REGION-docker.pkg.dev/$YUNTAI_UPDATE_PROJECT/yuntai/yuntai-api:captions-0.8.28-$(date -u +%Y%m%d%H%M%S)"
gcloud builds submit "$YUNTAI_UPDATE_DIR" --config="$YUNTAI_UPDATE_DIR/cloudbuild.yaml" \
 --substitutions="_IMAGE=$YUNTAI_UPDATE_IMAGE" \
 --service-account="projects/$YUNTAI_UPDATE_PROJECT/serviceAccounts/yuntai-build@$YUNTAI_UPDATE_PROJECT.iam.gserviceaccount.com" --project="$YUNTAI_UPDATE_PROJECT"
YUNTAI_UPDATE_ARGS=(--image="$YUNTAI_UPDATE_IMAGE" --project="$YUNTAI_UPDATE_PROJECT" --region="$YUNTAI_UPDATE_REGION")
if [[ "$YUNTAI_UPDATE_AUTH" == play_integrity ]]; then YUNTAI_UPDATE_ARGS+=(--update-env-vars=YUNTAI_PACKAGE=com.yuntai.android.apps.livetv);fi
gcloud run services update "$YUNTAI_UPDATE_SERVICE" "${YUNTAI_UPDATE_ARGS[@]}"
YUNTAI_UPDATE_URL="$(gcloud run services describe "$YUNTAI_UPDATE_SERVICE" --project="$YUNTAI_UPDATE_PROJECT" --region="$YUNTAI_UPDATE_REGION" --format='value(status.url)')"
curl -fsS --max-time 30 "$YUNTAI_UPDATE_URL/v1/health"
python3 - "$YUNTAI_UPDATE_URL" <<'PY'
import json,sys,urllib.request,urllib.error
request=urllib.request.Request(sys.argv[1]+'/v1/translate',data=b'{}',headers={'Content-Type':'application/json'})
try:
    urllib.request.urlopen(request,timeout=20)
    raise SystemExit('Consent check unexpectedly succeeded; investigate.')
except urllib.error.HTTPError as error:
    reply=json.loads(error.read(4096))
    if error.code!=400 or reply.get('error')!='subtitle_consent_required':
        raise SystemExit('Text route verification failed. No audio, text or API key was submitted.')
print('\nTranslation route deployed; unauthenticated consent-free requests rejected. This is not an end-to-end caption test.')
PY
printf '\nExisting authorization mode retained: %s\n' "$YUNTAI_UPDATE_AUTH"
