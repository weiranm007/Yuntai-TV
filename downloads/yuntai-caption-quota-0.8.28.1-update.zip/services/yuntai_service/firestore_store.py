"""Shared transactional state for Cloud Run. No audio/transcript persistence.

SDK transaction retries contain database operations only, never Groq/Google calls.
TTL is for cleanup; request authorization checks expiry synchronously.
"""
from datetime import datetime, timezone

from google.cloud import firestore
from google.api_core.exceptions import GoogleAPICallError, RetryError

from .core import Denied, Store, digest
import secrets


class FirestoreStore(Store):
    def __init__(self, client, secret, integrity, captions, device_seconds=7200, global_seconds=7200, global_rpm=18, auth_mode="play_integrity"):
        self._runtime(secret, integrity, captions, device_seconds, global_seconds, global_rpm, auth_mode)
        self.client = client

    def _ref(self, collection, identifier):
        return self.client.collection('yuntai_'+collection).document(identifier)

    @staticmethod
    def _read(ref, transaction=None):
        return ref.get(transaction=transaction, retry=None, timeout=3).to_dict()

    @staticmethod
    def _expiry(value):
        return datetime.fromtimestamp(value, timezone.utc)

    def _transaction(self, function):
        try:
            return firestore.transactional(function)(self.client.transaction(max_attempts=3))
        except Denied:
            raise
        except (GoogleAPICallError, RetryError, ValueError):
            raise Denied(503, 'state_unavailable', 10) from None

    def _quota_reads(self, transaction, specs):
        # Firestore requires every read to precede every write in a transaction.
        day = int(self.clock()//86400)
        pending = []
        for scope, amount, maximum in specs:
            ref = self._ref('budgets', digest((str(day)+':'+scope).encode()))
            row = self._read(ref, transaction)
            used = row.get('used', 0) if row else 0
            if used+amount > maximum:
                raise Denied(429, 'quota_reached', max(1,int((day+1)*86400-self.clock())) if scope.startswith('audio:') else 60)
            pending.append((ref, {'used':used+amount,'expires_at':self._expiry((day+3)*86400)}))
        return pending

    @staticmethod
    def _quota_writes(transaction, pending):
        for ref, value in pending:
            transaction.set(ref, value)

    def _save_challenge(self, nonce, device, public, peer):
        def save(transaction):
            pending = self._quota_reads(transaction, [
                ('challenge:'+peer+':'+str(int(self.clock()//60)),1,30),('challenge:global',1,5000)])
            self._quota_writes(transaction, pending)
            expires = int(self.clock())+90
            transaction.create(self._ref('challenges', nonce), {'device':device,'pub':public,
                'expires':expires,'expires_at':self._expiry(expires)})
        self._transaction(save)

    def _consume_challenge(self, nonce, peer):
        # Bound and validate document IDs before issuing a Firestore RPC.
        if not isinstance(nonce, str) or len(nonce)>128 or '/' in nonce:
            raise Denied(400)
        def consume(transaction):
            ref = self._ref('challenges', nonce)
            row = self._read(ref, transaction)
            if row is None or row['expires']<self.clock():
                raise Denied()
            pending = self._quota_reads(transaction, [('session:'+peer+':'+str(int(self.clock()//60)),1,30)])
            self._quota_writes(transaction, pending)
            transaction.delete(ref)
            return row
        return self._transaction(consume)

    def _save_session(self, hashed, device, public, grant_revision=""):
        expires = int(self.clock())+900
        self._ref('sessions', hashed).create({'device':device,'pub':public,'expires':expires,'auth_mode':self.auth_mode,'grant_revision':grant_revision,
            'expires_at':self._expiry(expires)}, retry=None, timeout=3)

    def _find_session(self, hashed):
        return self._read(self._ref('sessions', hashed))

    def _reserve_request(self, hashed, request_id, session, audio):
        def reserve(transaction):
            current = self._read(self._ref('sessions', hashed), transaction)
            if current is None or current['pub']!=session['pub'] or current['expires']<self.clock():
                raise Denied(401, 'session_expired')
            if self.auth_mode=='private_beta':
                grant=self._read(self._ref('sessions','device_'+session['device']),transaction)
                if not self._grant_valid(grant,session['pub'],session.get('grant_revision','')):
                    raise Denied(403,'device_not_approved')
            ref = self._ref('requests', digest((hashed+':'+request_id).encode()))
            if self._read(ref, transaction) is not None:
                raise Denied(403, 'replay_or_signature')
            slots = []
            if audio:
                for number in range(2):
                    slot = self._ref('inflight', str(number))
                    slots.append((slot, self._read(slot, transaction)))
                available = next((slot for slot, value in slots if value is None or value['expires']<=self.clock()), None)
                if available is None:
                    raise Denied(429, 'busy', 10)
            pending = self._quota_reads(transaction, self._budgets(session['device'], audio))
            self._quota_writes(transaction, pending)
            transaction.create(ref, {'expires_at':self._expiry(current['expires'])})
            if audio:
                expires = int(self.clock())+30
                transaction.set(available, {'owner':ref.id,'expires':expires,'expires_at':self._expiry(expires)})
        self._transaction(reserve)

    def _find_device(self, device):
        return self._read(self._ref('sessions','device_'+device))

    def _request_pairing(self, device, public):
        def request(transaction):
            ref=self._ref('requests','pair_'+device)
            row=self._read(ref,transaction)
            if row and row.get('kind')=='pairing' and row.get('pub')==public and row.get('expires',0)>self.clock():
                return row
            pending=self._quota_reads(transaction,[('pairing:global',1,200),('pairing:'+device,1,12)])
            # Reserve the short code in the same transaction as the device pairing.
            # Keep reservations until expiry even after approval, preventing immediate reuse.
            code=None
            for _ in range(32):
                candidate=f'{secrets.randbelow(10000):04d}'
                code_ref=self._ref('requests','code_'+candidate)
                occupied=self._read(code_ref,transaction)
                if not occupied or occupied.get('expires',0)<=self.clock():
                    code=candidate;break
            if code is None:raise Denied(429,'pairing_busy',30)
            self._quota_writes(transaction,pending)
            expires=int(self.clock())+300
            transaction.set(code_ref,{'kind':'pairing_code','device':device,'expires':expires,'expires_at':self._expiry(expires)})
            value={'kind':'pairing','device':device,'pub':public,'code':code,
                'expires':expires,'expires_at':self._expiry(expires)}
            transaction.set(ref,value)
            return value
        return self._transaction(request)

    def _release_caption(self, headers):
        token = headers.get('Authorization','').removeprefix('Bearer ')
        request_id = headers.get('X-Request-ID','')
        owner = digest((digest(token.encode())+':'+request_id).encode())
        def release(transaction):
            slots = [(self._ref('inflight',str(i)),None) for i in range(2)]
            slots = [(ref,self._read(ref,transaction)) for ref,_ in slots]
            for ref, value in slots:
                if value and value.get('owner')==owner:
                    transaction.delete(ref)
        try:
            self._transaction(release)
        except Exception:
            pass  # Fail closed until the 30s lease expires, without logging sensitive requests.

    def _save_feedback(self, identifier, report):
        def save(transaction):
            cursor = self._ref('settings', 'feedback_cursor')
            row = self._read(cursor, transaction)
            position = row.get('next',0) if row else 0
            # Fixed-size ring: storage remains bounded even if TTL deletion is delayed.
            transaction.set(cursor, {'next':(position+1)%10000})
            transaction.set(self._ref('reports',str(position%10000)), {'id':identifier,
                'created':int(self.clock()), 'expires_at':self._expiry(int(self.clock())+14*86400),
                'payload':report})
        self._transaction(save)
