"""Operator-managed captions and privacy-minimal feedback. Not a stream proxy."""
