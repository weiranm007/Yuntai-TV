"""Owner-only beta approval via Cloud Shell IAM. No public approval API or shared key.

Uses the standard library and gcloud's existing login. Never reads Groq secrets.
"""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import re
import secrets
import subprocess
import time
import urllib.error
import urllib.request


class DeviceError(Exception):
    pass


def fields(value):
    out={}
    for key,item in value.items():
        if isinstance(item,bool):out[key]={'booleanValue':item}
        elif isinstance(item,int):out[key]={'integerValue':str(item)}
        elif isinstance(item,datetime):out[key]={'timestampValue':item.astimezone(timezone.utc).isoformat().replace('+00:00','Z')}
        else:out[key]={'stringValue':str(item)}
    return out


def values(document):
    result={}
    for key,item in document.get('fields',{}).items():
        if 'integerValue' in item:result[key]=int(item['integerValue'])
        elif 'booleanValue' in item:result[key]=item['booleanValue']
        elif 'stringValue' in item:result[key]=item['stringValue']
    return result


class DeviceAdmin:
    def __init__(self,project,token,request=None):
        if not re.fullmatch(r'[a-z][a-z0-9-]{4,28}[a-z0-9]',project):raise DeviceError('Invalid project ID')
        self.root='https://firestore.googleapis.com/v1/projects/'+project+'/databases/(default)/documents'
        self.document_root='projects/'+project+'/databases/(default)/documents'
        self.token=token
        self.request_override=request

    def request(self,path,body=None):
        if self.request_override:return self.request_override(path,body)
        request=urllib.request.Request(self.root+path,data=json.dumps(body).encode() if body is not None else None,
            headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(request,timeout=15) as response:
                data=response.read(131073)
                if len(data)>131072:raise DeviceError('Response too large')
                return json.loads(data)
        except urllib.error.HTTPError as failure:
            if failure.code==404 and body is None:return None
            if failure.code in (409,412):raise DeviceError('Record changed or approval code was consumed. Refresh and retry.') from None
            raise DeviceError('Firestore request failed (HTTP '+str(failure.code)+'). Check your Cloud Shell login and IAM permissions.') from None

    def query(self,collection,field,value):
        response=self.request(':runQuery',{'structuredQuery':{'from':[{'collectionId':collection}],
            'where':{'fieldFilter':{'field':{'fieldPath':field},'op':'EQUAL','value':{'stringValue':value}}},'limit':20}})
        return [item['document'] for item in response or [] if 'document' in item]

    def inspect_pairing(self,code,fingerprint=None):
        code=code.replace('-','').upper()
        fingerprint=fingerprint.lower() if fingerprint else None
        if not re.fullmatch(r'(?:[0-9]{4}|[A-F0-9]{12})',code) or (fingerprint is not None and not re.fullmatch(r'(?:[a-f0-9]{16}|[a-f0-9]{64})',fingerprint)):
            raise DeviceError('Copy the pairing code and device fingerprint from the TV/tablet.')
        if len(code)==4:
            reservation=self.request('/yuntai_requests/code_'+code)
            slot=values(reservation) if reservation else {}
            owner=slot.get('device','')
            if slot.get('kind')!='pairing_code' or slot.get('expires',0)<=time.time()+5 or not re.fullmatch(r'[a-f0-9]{64}',owner):
                raise DeviceError('Pairing code expired or not found. Refresh on the device.')
            candidate=self.request('/yuntai_requests/pair_'+owner)
            found=[candidate] if candidate and values(candidate).get('code')==code else []
        else:
            found=[r for r in self.query('yuntai_requests','code',code) if values(r).get('expires',0)>time.time()+5]
        if len(found)!=1:raise DeviceError('Pairing code not found, consumed, or ambiguous. Refresh on the device.')
        pending=found[0];row=values(pending);device=row.get('device','')
        if row.get('kind')!='pairing' or not re.fullmatch(r'[a-f0-9]{64}',device) or (fingerprint is not None and not device.startswith(fingerprint)):
            raise DeviceError('Device fingerprint does not match. No approval made.')
        if row.get('expires',0)<=time.time()+5:raise DeviceError('Pairing code expired or too close to expiry. Refresh on the device.')
        if pending['name']!=self.document_root+'/yuntai_requests/pair_'+device:raise DeviceError('Unexpected pairing record')
        try:public=base64.urlsafe_b64decode(row['pub']+'='*(-len(row['pub'])%4))
        except Exception:raise DeviceError('Invalid public key record') from None
        if hashlib.sha256(public).hexdigest()!=device:raise DeviceError('Public key fingerprint mismatch')
        return pending,row,device

    def approve(self,code,fingerprint,days=30):
        if not 1<=days<=30:raise DeviceError('Approval duration must be 1 to 30 days')
        pending,row,device=self.inspect_pairing(code,fingerprint)
        path='/yuntai_sessions/device_'+device
        existing=self.request(path)
        expires=int(time.time())+days*86400
        approved={'kind':'device','device':device,'pub':row['pub'],'enabled':True,'expires':expires,
            'expires_at':datetime.fromtimestamp(expires,timezone.utc),'revision':secrets.token_hex(16)}
        precondition={'updateTime':existing['updateTime']} if existing else {'exists':False}
        self.request(':commit',{'writes':[
            {'update':{'name':self.document_root+path,'fields':fields(approved)},'currentDocument':precondition},
            {'delete':pending['name'],'currentDocument':{'updateTime':pending['updateTime']}}]})
        return device

    def revoke(self,device):
        if not re.fullmatch(r'[a-f0-9]{64}',device):raise DeviceError('Use the full device ID printed by approve or list')
        path='/yuntai_sessions/device_'+device
        existing=self.request(path)
        if not existing:raise DeviceError('Device not found')
        row=values(existing)
        if row.get('kind')!='device':raise DeviceError('Unexpected device record')
        row['enabled']=False;row['revision']=secrets.token_hex(16)
        row['expires']=int(time.time())+30*86400
        row['expires_at']=datetime.fromtimestamp(row['expires'],timezone.utc)
        self.request(':commit',{'writes':[{'update':{'name':existing['name'],'fields':fields(row)},
            'currentDocument':{'updateTime':existing['updateTime']}}]})

    def listing(self):
        return [{'device':row.get('device'),'enabled':bool(row.get('enabled')) and row.get('expires',0)>time.time(),
            'expires':row.get('expires')} for row in map(values,self.query('yuntai_sessions','kind','device'))]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',default='yuntai-app')
    actions=parser.add_subparsers(dest='action',required=True)
    approve=actions.add_parser('approve');approve.add_argument('code');approve.add_argument('--fingerprint');approve.add_argument('--days',type=int,default=30)
    revoke=actions.add_parser('revoke');revoke.add_argument('device')
    actions.add_parser('list')
    args=parser.parse_args()
    try:
        token=subprocess.check_output(['gcloud','auth','print-access-token'],text=True,stderr=subprocess.DEVNULL).strip()
        admin=DeviceAdmin(args.project,token)
        if args.action=='approve':
            fingerprint=args.fingerprint
            if fingerprint is None:
                _,row,device=admin.inspect_pairing(args.code)
                print('Pending device fingerprint: '+device[:16])
                print('Approval duration: '+str(args.days)+' days. Confirm this pairing code is on your device.')
                if input('Approve this device? [y/N]: ').strip().lower()!='y':
                    raise DeviceError('Cancelled; no approval made.')
                fingerprint=device  # Revalidate identity after confirmation, never trust code alone.
            print('Approved device: '+admin.approve(args.code,fingerprint,args.days)+'\nPress Check authorization on the TV/tablet.')
        elif args.action=='revoke':admin.revoke(args.device);print('Revoked. New requests using existing sessions will be denied.')
        else:print(json.dumps(admin.listing(),indent=2))
    except DeviceError as failure:raise SystemExit(str(failure)) from None
    except Exception:raise SystemExit('Device operation failed. Check login/project/network; no credentials are printed.') from None


if __name__=='__main__':main()
